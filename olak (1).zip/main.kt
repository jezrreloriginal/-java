fun main() {
  
  println("abner jezrrel")
 //_____________________________________ 
  var nome = "abner"
  var nascimento = 2005

  println( 5 + 60)
  println(nome)
  println (nascimento)
//_____________________________________
val myNum = 9          
val myDoubleNum = 8.99    
val myLetter = 'L'        
val myBoolean = false      
val myText = "caralho"  

  println(myNum)
  println(myDoubleNum)
  println(myLetter)
  println(myBoolean)
  println(myText)
//_____________________________________
  



}